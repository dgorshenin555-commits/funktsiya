# Handoff: плавающий док «Начать проект» (фиксированное левое меню)

## Overview
Это **фиксированная плавающая панель быстрых действий**, закреплённая слева по центру экрана главной страницы. Заголовок — **«Начать проект»**. Остаётся на месте при прокрутке (`position: fixed`), имеет 3D-наклон вслед за курсором мыши и параллакс-подъём пунктов при наведении.

В коде это React-компонент **`QuickDock`** (CSS-класс корня `.tl-dock`). Он рендерится первым внутри лендинга:
```jsx
<main className="tl"><QuickDock go={go} /> ...остальные секции... </main>
```

## About the Design Files
Файлы — **дизайн-референс в HTML/React (JSX через Babel)**: прототип задуманного вида и поведения, **не продакшен-код для копирования напрямую**. Задача — **воссоздать этот элемент в среде вашего проекта** (React / Vue / и т.д.) средствами вашей дизайн-системы. Ниже приведён **полный исходник компонента и его стилей** — этого достаточно, чтобы реализовать панель без доступа к остальному проекту.

## Fidelity
**High-fidelity (hifi).** Финальные размеры, цвета, типографика, состояния и анимации.

---

## Поведение
- **Позиция:** `position: fixed; left: 22px; top: 50%; transform: translateY(-50%)`. Не двигается при скролле. `z-index: 60`.
- **3D-наклон:** при движении мыши по окну вся панель (`.tl-dock__bar`) наклоняется — `perspective(1100px) rotateX(rx) rotateY(ry)`, где базовый `ry = 13°`. Формула из обработчика `mousemove`: `rx = -(clientY/innerH - 0.5) * 9`, `ry = 13 + (clientX/innerW - 0.5) * 9`. Обновление через `requestAnimationFrame`. Отключается при `prefers-reduced-motion: reduce`.
- **Параллакс пунктов при hover:** наведённый пункт выезжает вперёд `translateZ(46px) scale(1.05)`; остальные уходят назад `translateZ(-14px)` и притухают до `opacity: 0.58`. Без наведения — `translateZ(0)`, `opacity: 1`.
- **Адаптив:** при ширине окна `≤ 1180px` панель скрывается (`display: none`).
- **Навигация:** клик по пункту вызывает `go(it.to)` — переход на соответствующий экран.

## Структура и контент
Панель состоит из заголовка, **двух «путей»** (paths), разделителя и **четырёх «действий»** (items). Все пункты используют одну вёрстку (иконка-плитка + заголовок + подпись), различаются цветовым тоном (`tone`).

**Заголовок:** «Начать проект»

**Пути (paths):**
| Иконка | Заголовок | Подпись | tone | Переход |
|---|---|---|---|---|
| `factory` | Коммерция, промышленность | Бизнес-объект | `amber` | `order-new` |
| `home` | Строю свой дом | Частный проект | `home` | `order-new` |

**Разделитель** (`.tl-dock__div`)

**Действия (items):**
| Иконка | Заголовок | Подпись | tone | Переход |
|---|---|---|---|---|
| `plus` | Разместить заявку | Опубликовать проект | `primary` | `order-new` |
| `search` | Найти заказы | Биржа проектов | `pink` | `auth` |
| `box` | Каталог решений | Решения и подбор | `green` | `manufacturers` |
| `database` | Нормативы | ГОСТ, СП, ТУ | `blue` | `standards` |

Иконки — из набора `icons.jsx` (`<Icon name size />`), размер 22px. См. файл `icons.jsx` в пакете.

---

## Полный исходник компонента (JSX)

```jsx
function QuickDock({ go }) {
  const [tilt, setTilt] = React.useState({ rx: 0, ry: 13 });
  const [hover, setHover] = React.useState(null);

  React.useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf;
    const onMove = (e) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const x = e.clientX / window.innerWidth - 0.5;
        const y = e.clientY / window.innerHeight - 0.5;
        setTilt({ rx: -y * 9, ry: 13 + x * 9 });
      });
    };
    window.addEventListener("mousemove", onMove);
    return () => { window.removeEventListener("mousemove", onMove); cancelAnimationFrame(raf); };
  }, []);

  const paths = [
    { ic: "factory", label: "Коммерция, промышленность", sub: "Бизнес-объект", to: "order-new", tone: "amber" },
    { ic: "home",    label: "Строю свой дом",            sub: "Частный проект", to: "order-new", tone: "home" },
  ];
  const items = [
    { ic: "plus",     label: "Разместить заявку", sub: "Опубликовать проект", to: "order-new",     tone: "primary" },
    { ic: "search",   label: "Найти заказы",      sub: "Биржа проектов",      to: "auth",          tone: "pink" },
    { ic: "box",      label: "Каталог решений",   sub: "Решения и подбор",    to: "manufacturers", tone: "green" },
    { ic: "database", label: "Нормативы",         sub: "ГОСТ, СП, ТУ",        to: "standards",     tone: "blue" },
  ];

  const item = (it) => (
    <button key={it.label} className={"tl-dock__item tl-dock__item--" + it.tone}
      onClick={() => go && go(it.to)}
      onMouseEnter={() => setHover(it.label)} onMouseLeave={() => setHover(null)}
      style={{
        transform: hover === it.label ? "translateZ(46px) scale(1.05)"
                 : hover !== null ? "translateZ(-14px)" : "translateZ(0)",
        opacity: hover !== null && hover !== it.label ? 0.58 : 1
      }}>
      <span className="tl-dock__ic"><Icon name={it.ic} size={22} /></span>
      <span className="tl-dock__tx"><b>{it.label}</b><span>{it.sub}</span></span>
    </button>
  );

  return (
    <div className="tl-dock" aria-label="Быстрые действия">
      <div className="tl-dock__bar" style={{ transform: `perspective(1100px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)` }}>
        <div className="tl-dock__head">Начать проект</div>
        {paths.map(item)}
        <div className="tl-dock__div" />
        {items.map(item)}
      </div>
    </div>
  );
}
```

## Полный исходник стилей (CSS)

```css
/* ---- floating quick-action dock (3D tilt + parallax) ---- */
.tl-dock { position: fixed; left: 22px; top: 50%; transform: translateY(-50%); z-index: 60; pointer-events: none; }
.tl-dock__bar { display: flex; flex-direction: column; gap: 12px; padding: 13px; border-radius: 22px; transform-style: preserve-3d; transition: transform .35s ease-out; pointer-events: auto; backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); background: rgba(12,12,20,.42); border: 1px solid rgba(255,255,255,.12); box-shadow: 0 15px 40px rgba(0,0,0,.45), inset 0 1px 0 rgba(255,255,255,.12); }
.tl-dock__item { display: flex; align-items: center; gap: 13px; width: 212px; padding: 13px 15px; border-radius: 16px; border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); color: #fff; cursor: pointer; font-family: inherit; text-align: left; transform-style: preserve-3d; transition: transform .5s cubic-bezier(.175,.885,.32,1.4), opacity .3s ease, background .25s ease, border-color .25s ease; }
.tl-dock__item:hover { background: rgba(255,255,255,.11); border-color: rgba(255,255,255,.3); }
.tl-dock__ic { width: 42px; height: 42px; border-radius: 13px; display: grid; place-items: center; flex: 0 0 auto; box-shadow: inset 0 1px 0 rgba(255,255,255,.25); }
.tl-dock__tx { display: flex; flex-direction: column; line-height: 1.2; }
.tl-dock__tx b { font-size: 14.5px; font-weight: 600; }
.tl-dock__tx span { font-size: 11.5px; color: rgba(255,255,255,.55); margin-top: 3px; }
.tl-dock__item--primary { border-color: var(--accent-line); }
.tl-dock__item--primary .tl-dock__ic { background: var(--grad); color: #fff; }
.tl-dock__item--pink .tl-dock__ic { background: #ef6f9e; color: #2a0e1a; }
.tl-dock__item--green .tl-dock__ic { background: var(--green); color: #06281d; }
.tl-dock__item--blue .tl-dock__ic { background: var(--blue); color: #08203f; }
.tl-dock__item--amber .tl-dock__ic { background: var(--amber); color: #2b1c05; }
.tl-dock__item--home { background: linear-gradient(150deg, color-mix(in srgb, var(--accent) 32%, transparent), rgba(255,255,255,.05)); border-color: var(--accent-line); }
.tl-dock__item--home .tl-dock__ic { background: var(--grad); color: #fff; }
.tl-dock__head { font-size: 10.5px; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: rgba(255,255,255,.45); padding: 2px 6px 4px; }
.tl-dock__div { height: 1px; margin: 4px 6px; background: rgba(255,255,255,.12); }
@media (max-width: 1180px) { .tl-dock { display: none; } }
```

---

## Design Tokens (CSS-переменные)
Используются в стилях; задайте их в своём проекте либо подставьте конкретные значения вашей дизайн-системы:
- `--grad` — основной градиент бренда (фон иконок primary/home).
- `--accent` — основной акцентный цвет (используется в `color-mix` для фона пункта `home`).
- `--accent-line` — цвет акцентного бордера.
- `--green`, `--blue`, `--amber` — цвета фона иконок соответствующих тонов.
- Цвета подложек/бликов в доке заданы напрямую: `rgba(12,12,20,.42)`, `rgba(255,255,255,.12)` и т.п.
- Текст иконок на цветном фоне — тёмные оттенки под каждый тон (`#2a0e1a`, `#06281d`, `#08203f`, `#2b1c05`).

## Размеры (ключевые)
- Панель: смещение от левого края `22px`, по вертикали — центр (`top:50%` + `translateY(-50%)`).
- `.tl-dock__bar`: padding 13px, `border-radius: 22px`, `backdrop-filter: blur(16px)`.
- Пункт: ширина **212px**, padding `13px 15px`, `border-radius: 16px`, gap 13px.
- Иконка-плитка: **42×42**, `border-radius: 13px`, иконка внутри 22px.
- Заголовок пункта: 14.5px / weight 600; подпись: 11.5px, `rgba(255,255,255,.55)`.
- Заголовок панели: 10.5px, weight 700, uppercase, `letter-spacing: .12em`.

## Assets / зависимости
- **Иконки:** `icons.jsx` — компонент `<Icon name size />` (SVG stroke). Имена, нужные доку: `factory`, `home`, `plus`, `search`, `box`, `database`.
- React (через ваш проект). В прототипе — React 18 + Babel standalone.

## Files в этом пакете
- `QuickDock.jsx` — изолированный исходник компонента (то же, что выше).
- `quick-dock.css` — изолированные стили дока.
- `icons.jsx` — набор иконок (для нужных глифов).
- `test_landing.jsx` / `test_landing.css` — полный лендинг, для контекста (док вызывается в `TestLanding`).
