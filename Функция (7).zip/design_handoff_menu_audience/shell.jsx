/* shell.jsx — AppShell (sidebar + topbar + legend). window.Shell, window.Avatar */
(function () {
  const Icon = window.Icon;
  const FuncMark = window.FuncMark;

  const GROUPS = [
    { title: "Работа", items: [
      { key: "orders",        label: "Заявки",                icon: "grid",     c: "var(--accent-2)" },
      { key: "expertise",     label: "Обследование",          icon: "scan",     c: "var(--blue)" },
    ]},
    { title: "Подбор", items: [
      { key: "designers",     label: "Проектировщики",        icon: "pen",      c: "var(--green)" },
      { key: "experts",       label: "Инженер-обследователь", icon: "shield",   c: "var(--amber)" },
      { key: "manufacturers", label: "Производители",         icon: "stamp",    c: "var(--pink)" },
    ]},
    { title: "База знаний", items: [
      { key: "standards",     label: "Нормативы",             icon: "database", c: "var(--accent)" },
      { key: "chat",          label: "Коммуникации",          icon: "chat",     c: "var(--green)" },
      { key: "analytics",     label: "Аналитика",             icon: "chart",    c: "var(--blue)" },
    ]},
    { title: "Аккаунт", items: [
      { key: "pricing",       label: "Тарифы",                icon: "wallet",   c: "var(--amber)" },
      { key: "settings",      label: "Настройки",             icon: "sliders",  c: "var(--text-dim)" },
    ]},
  ];

  // parent screen for sub-views (so nav stays highlighted)
  const PARENT = { "order-detail": "orders", "designer-profile": "designers", "order-new": "orders", "expertise-detail": "expertise" };

  const LEGEND = [
    ["Заявки", "var(--accent-2)"], ["Обследование", "var(--blue)"], ["Проектировщики", "var(--green)"],
    ["Инженер-обследователь", "var(--amber)"], ["Производители", "var(--pink)"], ["Нормативы", "var(--accent)"],
  ];

  function Avatar({ text, size = 36, style }) {
    return <div className="avatar" style={{ width: size, height: size, fontSize: size * 0.36, ...style }}>{text}</div>;
  }

  function Shell({ active, go, children, scrollKey, flush }) {
    const cur = PARENT[active] || active;
    const contentRef = React.useRef(null);
    React.useEffect(() => { if (contentRef.current) contentRef.current.scrollTop = 0; }, [scrollKey]);
    return (
      <div className="app app--tm">
        {/* sidebar — grouped dock-style */}
        <aside className="tm-side">
          <div className="tm-brand" onClick={() => go("landing")} title="На главную">
            <FuncMark size={24} />
            <div className="brand__name">ФУНКЦИЯ</div>
          </div>
          <nav className="tm-nav">
            {GROUPS.map(g => (
              <div className="tm-group" key={g.title}>
                <div className="tm-head">{g.title}</div>
                {g.items.map(n => (
                  <button key={n.key} className={"tm-item" + (cur === n.key ? " is-active" : "")} style={{ "--c": n.c }} onClick={() => go(n.key)}>
                    <span className="tm-chip"><Icon name={n.icon} size={19} /></span>
                    <span className="tm-label">{n.label}</span>
                  </button>
                ))}
              </div>
            ))}
          </nav>
          <div className="tm-foot" onClick={() => go("settings")}>
            <Avatar text="ДП" size={38} />
            <div>
              <div className="meta-name">Демо Пользователь</div>
              <div className="meta-sub">demo@funktsiya.ru</div>
            </div>
          </div>
        </aside>

        {/* main */}
        <div className="main">
          <header className="topbar">
            <button className="iconbtn"><Icon name="menu" /></button>
            <div className="topbar__search">
              <Icon name="search" /><input placeholder="Поиск по заявкам" />
            </div>
            <div className="topbar__user">
              <span>Демо Пользователь</span>
              <Avatar text="ДП" size={36} />
            </div>
          </header>

          <div className={"content" + (flush ? " content--flush" : "")} ref={contentRef}>
            <div className={(flush ? "content__flush" : "content__inner") + " fade-in"} key={scrollKey}>{children}</div>
          </div>

          <footer className="legend">
            {LEGEND.map(([l, c]) => (
              <span key={l}><i style={{ background: c }} />{l}</span>
            ))}
          </footer>
        </div>
      </div>
    );
  }

  Object.assign(window, { Shell, Avatar });
})();
